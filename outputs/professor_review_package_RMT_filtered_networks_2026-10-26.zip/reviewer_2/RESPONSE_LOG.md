# Registro de analise e resposta — Professor 2

| ID | Comentario original | Interpretacao | Acao proposta | Decisao | Alteracao e local no manuscrito | Resposta ao professor | Evidencia/estado |
|---|---|---|---|---|---|---|---|

